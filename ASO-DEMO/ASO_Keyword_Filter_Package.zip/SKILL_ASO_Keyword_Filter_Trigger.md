# 🎯 SKILL: ASO Keyword Filter Trigger & Automation

**SKILL_ID:** `aso_keyword_filter_trigger`  
**VERSION:** 2.1  
**AUTHOR:** AI Assistant  
**SCOPE:** Tự động hóa việc nhận diện lệnh kích hoạt, định tuyến và chạy pipeline lọc từ khóa ASO dựa trên cấu trúc tên file CSV được gửi trong thư mục `C:\Users\VOLIO\Documents\ASO-DEMO`.  
**RUNTIME:** Python 3.9+  

---

## 📥 TRIGGER CONDITIONS (Điều kiện kích hoạt)

Skill này được kích hoạt khi USER gửi yêu cầu trong chat chứa cụm từ khoá kích hoạt:
* **Cụm từ kích hoạt:** `Lọc từ khoá` hoặc `Lọc từ khóa` hoặc `Filter keywords`.
* **Tệp đính kèm:** Một tệp CSV chứa dữ liệu từ khoá thô, có cấu trúc đặt tên theo chuẩn:
  ```
  {AppName}_{Country}_{Language}.csv
  ```
  *Ví dụ:* `ARFilter_US_EN.csv`, `ControlWidget_BR_PT.csv`, `GameEmulator_US_EN.csv`.

---

## 🔄 WORKFLOW STEPS FOR AGENT (Các bước Agent thực hiện)

Khi điều kiện kích hoạt được đáp ứng, Agent PHẢI thực hiện tuần tự các bước sau:

### Bước 1: Xác thực và Chuẩn bị tệp đầu vào
1. Nhận diện file CSV được gửi.
2. Kiểm tra cấu trúc tên file để trích xuất `AppName` và mã thị trường `Country_Language` (ví dụ: `ARFilter` và `US_EN`).
3. Xác định tháng chạy dạng `MMYYYY` (ví dụ `052026`).
4. Script điều phối sẽ tự động copy/di chuyển file CSV này vào thư mục lưu trữ chuẩn: `[AppFolder]/Input/[Tháng]/` (ví dụ: `AR_Filter/Input/052026/ARFilter_US_EN.csv`).

### Bước 2: Kích hoạt Pipeline điều phối
Chạy bộ điều phối trung tâm [run_aso_filter.py](file:///C:/Users/VOLIO/Documents/ASO-DEMO/run_aso_filter.py) bằng Powershell/Terminal. Mặc định chạy chế độ không tương tác (headless):
```powershell
python C:\Users\VOLIO\Documents\ASO-DEMO\run_aso_filter.py --csv C:\Users\VOLIO\Documents\ASO-DEMO\<Ten_File_CSV>
```
*Lưu ý:* Nếu người dùng muốn mở giao diện Web UI tương tác để chỉnh sửa thủ công, hãy thêm cờ `--interactive` (hoặc `-i`):
```powershell
python C:\Users\VOLIO\Documents\ASO-DEMO\run_aso_filter.py --csv C:\Users\VOLIO\Documents\ASO-DEMO\<Ten_File_CSV> --interactive
```

### Bước 3: Phân tích & Trình bày kết quả cho USER
Sau khi script hoàn thành thành công:
1. Đọc tóm tắt kết quả từ log đầu ra.
2. Hiển thị báo cáo kết quả tóm tắt cho người dùng dưới dạng bảng Markdown:
   * Tổng số từ khóa thô (Total Raw).
   * Số lượng từ khóa sạch (After Clean).
   * Số lượng từ khóa tính năng (Features) và phong cách (Styles).
3. Gửi đường dẫn trực tiếp đến file Excel kết quả ở thư mục con tương ứng để người dùng có thể nhấp vào và mở ngay lập tức.
   * *Ví dụ link AR Filter:* [ARFilter_US-EN_Output.xlsx](file:///C:/Users/VOLIO/Documents/ASO-DEMO/AR_Filter/Output/052026/ARFilter_US-EN_Output.xlsx)
   * *Ví dụ link Control Widget:* [ControlWidget_US-EN_Output.xlsx](file:///C:/Users/VOLIO/Documents/ASO-DEMO/Control_Widget/Output/052026/ControlWidget_US-EN_Output.xlsx)
   * *Ví dụ link Game Emulator:* [GameEmulator_US-EN_Output.xlsx](file:///C:/Users/VOLIO/Documents/ASO-DEMO/Game_Emulator/Output/052026/GameEmulator_US-EN_Output.xlsx)

---

## ⚠️ RULES FOR AGENT (Quy tắc bắt buộc)
1. **Không chạy thủ công từng bước:** Luôn sử dụng bộ điều phối trung tâm [run_aso_filter.py](file:///C:/Users/VOLIO/Documents/ASO-DEMO/run_aso_filter.py).
2. **Không tìm kiếm ngoài thư mục làm việc:** Tất cả các thao tác và ghi file Excel/JSON phải được thực hiện hoàn toàn bên trong thư mục [ASO-DEMO](file:///C:/Users/VOLIO/Documents/ASO-DEMO).
3. **Độ tin cậy:** Đảm bảo không tự động mở giao diện Web UI tương tác trừ khi được người dùng yêu cầu rõ ràng hoặc chạy kèm cờ `--interactive`.
